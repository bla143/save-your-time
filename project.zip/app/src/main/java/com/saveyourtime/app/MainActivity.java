package com.saveyourtime.app;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.HapticFeedbackConstants;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

    private final Handler handler = new Handler(Looper.getMainLooper());
    private UsageStore store;
    private TimeRingView ring;
    private TextView status;
    private TextView usedText;
    private View setupCard;

    private final Runnable refresher = new Runnable() {
        @Override
        public void run() {
            refresh();
            handler.postDelayed(this, 1000L);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        store = new UsageStore(this);
        ring = findViewById(R.id.ring);
        status = findViewById(R.id.status);
        usedText = findViewById(R.id.used_text);
        setupCard = findViewById(R.id.setup_card);
        Button enable = findViewById(R.id.enable_button);

        enable.setOnClickListener(v -> openAccessibilitySettings());
        ring.setOnClickListener(this::onRingPressed);
    }

    @Override
    protected void onResume() {
        super.onResume();
        handler.removeCallbacks(refresher);
        handler.post(refresher);
    }

    @Override
    protected void onPause() {
        handler.removeCallbacks(refresher);
        super.onPause();
    }

    private void onRingPressed(View v) {
        v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY);
        if (!isServiceEnabled()) {
            Toast.makeText(this, R.string.toast_enable_first, Toast.LENGTH_SHORT).show();
            openAccessibilitySettings();
            return;
        }
        if (store.exhausted()) {
            Toast.makeText(this, R.string.toast_exhausted, Toast.LENGTH_SHORT).show();
            return;
        }
        boolean nowActive = !store.sessionActive();
        store.setSession(nowActive);
        Toast.makeText(this,
                nowActive ? R.string.toast_session_on : R.string.toast_session_off,
                Toast.LENGTH_SHORT).show();
        refresh();
    }

    private void refresh() {
        boolean enabled = isServiceEnabled();
        long used = store.usedMs();
        long limit = UsageStore.LIMIT_MS;
        long usedMin = used / 60000L;
        usedText.setText(getString(R.string.used_today, usedMin));

        setupCard.setVisibility(enabled ? View.GONE : View.VISIBLE);

        if (!enabled) {
            ring.setState(TimeRingView.STATE_SETUP, used, limit, getString(R.string.ring_setup));
            status.setText(R.string.status_setup);
        } else if (store.exhausted()) {
            ring.setState(TimeRingView.STATE_EXHAUSTED, used, limit, getString(R.string.ring_exhausted));
            status.setText(R.string.status_exhausted);
        } else if (store.sessionActive()) {
            ring.setState(TimeRingView.STATE_ACTIVE, used, limit, getString(R.string.ring_active));
            status.setText(R.string.status_active);
        } else {
            ring.setState(TimeRingView.STATE_LOCKED, used, limit, getString(R.string.ring_locked));
            status.setText(R.string.status_locked);
        }
    }

    private boolean isServiceEnabled() {
        String list = Settings.Secure.getString(getContentResolver(),
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        if (list == null || list.isEmpty()) return false;
        String full = new ComponentName(this, ReelsBlockerService.class).flattenToString();
        String shortName = new ComponentName(this, ReelsBlockerService.class).flattenToShortString();
        for (String part : list.split(":")) {
            if (part.equalsIgnoreCase(full) || part.equalsIgnoreCase(shortName)) return true;
        }
        return false;
    }

    private void openAccessibilitySettings() {
        try {
            Intent i = new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (ActivityNotFoundException e) {
            startActivity(new Intent(Settings.ACTION_SETTINGS));
        }
    }
}
