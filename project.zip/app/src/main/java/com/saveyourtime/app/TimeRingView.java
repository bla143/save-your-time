package com.saveyourtime.app;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.View;

/** The big round button: a ring that fills as today's hour is used. */
public class TimeRingView extends View {

    public static final int STATE_LOCKED = 0;
    public static final int STATE_ACTIVE = 1;
    public static final int STATE_EXHAUSTED = 2;
    public static final int STATE_SETUP = 3;

    private static final int COLOR_LOCKED = Color.parseColor("#2DD4BF");
    private static final int COLOR_ACTIVE = Color.parseColor("#FF8A4C");
    private static final int COLOR_EXHAUSTED = Color.parseColor("#F43F5E");
    private static final int COLOR_SETUP = Color.parseColor("#94A3B8");

    private final Paint track = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint arc = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint face = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint bigText = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint smallText = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF oval = new RectF();

    private int state = STATE_LOCKED;
    private float fraction = 0f;
    private String timeText = "60:00";
    private String label = "";
    private float pulse = 0f;
    private ValueAnimator pulseAnimator;

    public TimeRingView(Context context) {
        super(context);
        init();
    }

    public TimeRingView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    private float dp(float v) {
        return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    private float sp(float v) {
        return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, v, getResources().getDisplayMetrics());
    }

    private void init() {
        track.setStyle(Paint.Style.STROKE);
        track.setStrokeWidth(dp(16));
        track.setColor(Color.argb(38, 255, 255, 255));

        arc.setStyle(Paint.Style.STROKE);
        arc.setStrokeWidth(dp(16));
        arc.setStrokeCap(Paint.Cap.ROUND);

        glow.setStyle(Paint.Style.FILL);

        face.setStyle(Paint.Style.FILL);
        face.setColor(Color.parseColor("#0F2A2C"));

        bigText.setColor(Color.WHITE);
        bigText.setTextAlign(Paint.Align.CENTER);
        bigText.setTextSize(sp(54));
        bigText.setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));

        smallText.setColor(Color.parseColor("#CBD5E1"));
        smallText.setTextAlign(Paint.Align.CENTER);
        smallText.setTextSize(sp(15));
        smallText.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));

        setClickable(true);
        setFocusable(true);
    }

    public void setState(int newState, long usedMs, long limitMs, String newLabel) {
        state = newState;
        fraction = limitMs <= 0 ? 0f : Math.min(1f, Math.max(0f, usedMs / (float) limitMs));
        long remaining = Math.max(0L, limitMs - usedMs);
        long totalSec = (remaining + 999L) / 1000L;
        timeText = String.format(java.util.Locale.US, "%02d:%02d", totalSec / 60L, totalSec % 60L);
        label = newLabel == null ? "" : newLabel;
        setContentDescription(timeText + " " + label);
        updatePulse();
        invalidate();
    }

    private void updatePulse() {
        boolean want = state == STATE_ACTIVE;
        if (want && pulseAnimator == null) {
            pulseAnimator = ValueAnimator.ofFloat(0f, 1f);
            pulseAnimator.setDuration(1600L);
            pulseAnimator.setRepeatCount(ValueAnimator.INFINITE);
            pulseAnimator.setRepeatMode(ValueAnimator.REVERSE);
            pulseAnimator.addUpdateListener(a -> {
                pulse = (float) a.getAnimatedValue();
                invalidate();
            });
            pulseAnimator.start();
        } else if (!want && pulseAnimator != null) {
            pulseAnimator.cancel();
            pulseAnimator = null;
            pulse = 0f;
        }
    }

    private int colorForState() {
        switch (state) {
            case STATE_ACTIVE:
                return COLOR_ACTIVE;
            case STATE_EXHAUSTED:
                return COLOR_EXHAUSTED;
            case STATE_SETUP:
                return COLOR_SETUP;
            default:
                return COLOR_LOCKED;
        }
    }

    @Override
    protected void onDetachedFromWindow() {
        if (pulseAnimator != null) {
            pulseAnimator.cancel();
            pulseAnimator = null;
        }
        super.onDetachedFromWindow();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float w = getWidth();
        float h = getHeight();
        float cx = w / 2f;
        float cy = h / 2f;
        float stroke = arc.getStrokeWidth();
        float radius = Math.min(w, h) / 2f - stroke - dp(10);
        int color = colorForState();

        // Soft glow behind the ring
        float glowExtra = dp(6) + dp(10) * pulse;
        glow.setColor(Color.argb((int) (40 + 50 * pulse), Color.red(color), Color.green(color), Color.blue(color)));
        canvas.drawCircle(cx, cy, radius + stroke / 2f + glowExtra, glow);

        // Face
        canvas.drawCircle(cx, cy, radius - stroke / 2f, face);

        // Track + progress
        oval.set(cx - radius, cy - radius, cx + radius, cy + radius);
        canvas.drawOval(oval, track);
        arc.setColor(color);
        float sweep = 360f * fraction;
        if (state == STATE_EXHAUSTED) sweep = 360f;
        if (sweep > 0.5f) canvas.drawArc(oval, -90f, sweep, false, arc);

        // Texts
        float textY = cy + bigText.getTextSize() * 0.18f;
        canvas.drawText(timeText, cx, textY, bigText);
        smallText.setColor(color);
        canvas.drawText(label, cx, textY + smallText.getTextSize() * 2.0f, smallText);
    }
}
