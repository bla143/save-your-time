package com.saveyourtime.app;

import android.content.Context;
import android.content.SharedPreferences;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * Keeps today's reels allowance: one hour in total per day.
 * Time is only counted while a reels screen is actually on display.
 * Everything resets automatically at local midnight.
 */
public final class UsageStore {

    public static final long LIMIT_MS = 60L * 60L * 1000L; // 1 hour

    private static final String PREFS = "syt_prefs";
    private static final String K_DAY = "day";
    private static final String K_USED = "used_ms";
    private static final String K_SESSION = "session";

    private final SharedPreferences prefs;

    public UsageStore(Context context) {
        prefs = context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    private static String today() {
        return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());
    }

    private void rollover() {
        String t = today();
        if (!t.equals(prefs.getString(K_DAY, ""))) {
            prefs.edit()
                    .putString(K_DAY, t)
                    .putLong(K_USED, 0L)
                    .putBoolean(K_SESSION, false)
                    .apply();
        }
    }

    public synchronized long usedMs() {
        rollover();
        return Math.min(LIMIT_MS, Math.max(0L, prefs.getLong(K_USED, 0L)));
    }

    public long remainingMs() {
        return Math.max(0L, LIMIT_MS - usedMs());
    }

    public boolean exhausted() {
        return remainingMs() <= 0L;
    }

    /** True while the user has pressed the button and still has time left today. */
    public synchronized boolean sessionActive() {
        rollover();
        return prefs.getBoolean(K_SESSION, false) && !exhausted();
    }

    public synchronized void setSession(boolean on) {
        rollover();
        prefs.edit().putBoolean(K_SESSION, on && !exhausted()).apply();
    }

    public synchronized void addUsage(long ms) {
        if (ms <= 0L) return;
        rollover();
        long used = Math.min(LIMIT_MS, prefs.getLong(K_USED, 0L) + ms);
        SharedPreferences.Editor e = prefs.edit().putLong(K_USED, used);
        if (used >= LIMIT_MS) e.putBoolean(K_SESSION, false);
        e.apply();
    }
}
