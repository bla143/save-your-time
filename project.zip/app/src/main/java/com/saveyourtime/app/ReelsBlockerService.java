package com.saveyourtime.app;

import android.accessibilityservice.AccessibilityService;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Toast;

import java.util.ArrayDeque;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

/**
 * Watches Instagram, TikTok and X. When a short-video (reels) screen is on display:
 *  - if the user has opened a session and still has time today, the time is counted;
 *  - otherwise the screen is closed (Back for Instagram/X, Home for TikTok).
 */
public class ReelsBlockerService extends AccessibilityService {

    private static final String INSTAGRAM = "com.instagram.android";
    private static final String X_APP = "com.twitter.android";
    private static final Set<String> TIKTOK = new HashSet<>(Arrays.asList(
            "com.zhiliaoapp.musically",
            "com.ss.android.ugc.trill",
            "com.zhiliaoapp.musically.go",
            "com.ss.android.ugc.tiktok.lite"));

    /** View-id fragments of Instagram's full-screen Reels viewer. */
    private static final String[] IG_MARKERS = {"clips_viewer"};
    /** View-id fragments of X's full-screen swipeable video viewer. */
    private static final String[] X_MARKERS = {"immersive"};

    private static final long TICK_MS = 1000L;
    private static final int MAX_NODES = 700;

    private static volatile boolean running = false;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private UsageStore store;

    private boolean ticking = false;
    private long lastAccount = 0L;
    private long lastEval = 0L;
    private long lastBlock = 0L;
    private long lastToast = 0L;
    private int blockStreak = 0;
    private int nullRootStreak = 0;
    private String lastWindowPkg = "";
    private String lastWindowClass = "";

    public static boolean isRunning() {
        return running;
    }

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            if (evaluate()) {
                handler.postDelayed(this, TICK_MS);
            } else {
                ticking = false;
            }
        }
    };

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        store = new UsageStore(this);
        running = true;
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null || store == null) return;
        CharSequence p = event.getPackageName();
        if (p == null) return;
        String pkg = p.toString();

        if (event.getEventType() == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            lastWindowPkg = pkg;
            CharSequence cls = event.getClassName();
            lastWindowClass = cls == null ? "" : cls.toString();
        }

        if (!isTarget(pkg)) return;

        startTicking();
        long now = SystemClock.elapsedRealtime();
        if (now - lastEval >= 250L) {
            evaluate();
        }
    }

    private void startTicking() {
        if (ticking) return;
        ticking = true;
        lastAccount = SystemClock.elapsedRealtime();
        handler.postDelayed(tick, TICK_MS);
    }

    /** @return true while one of the watched apps is still in the foreground. */
    private boolean evaluate() {
        long now = SystemClock.elapsedRealtime();
        lastEval = now;
        long delta = now - lastAccount;
        lastAccount = now;

        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null || root.getPackageName() == null) {
            nullRootStreak++;
            return nullRootStreak < 5;
        }
        nullRootStreak = 0;

        String pkg = root.getPackageName().toString();
        if (!isTarget(pkg)) {
            blockStreak = 0;
            return false;
        }

        if (!isReelsScreen(pkg, root)) {
            blockStreak = 0;
            return true;
        }

        if (store.sessionActive()) {
            if (delta > 0L && delta < 5000L) store.addUsage(delta);
            if (!store.sessionActive()) block(pkg, store.exhausted());
        } else {
            block(pkg, store.exhausted());
        }
        return true;
    }

    private boolean isTarget(String pkg) {
        return INSTAGRAM.equals(pkg) || X_APP.equals(pkg) || TIKTOK.contains(pkg);
    }

    private boolean isReelsScreen(String pkg, AccessibilityNodeInfo root) {
        // TikTok is short videos from end to end, so the whole app counts.
        if (TIKTOK.contains(pkg)) return true;
        if (INSTAGRAM.equals(pkg)) return hasVisibleViewId(root, IG_MARKERS);
        if (X_APP.equals(pkg)) {
            boolean immersiveWindow = X_APP.equals(lastWindowPkg)
                    && lastWindowClass.toLowerCase(Locale.US).contains("immersive");
            return immersiveWindow || hasVisibleViewId(root, X_MARKERS);
        }
        return false;
    }

    private boolean hasVisibleViewId(AccessibilityNodeInfo root, String[] markers) {
        ArrayDeque<AccessibilityNodeInfo> queue = new ArrayDeque<>();
        queue.add(root);
        int visited = 0;
        while (!queue.isEmpty() && visited < MAX_NODES) {
            AccessibilityNodeInfo node = queue.poll();
            visited++;
            String id = node.getViewIdResourceName();
            if (id != null && node.isVisibleToUser()) {
                String lower = id.toLowerCase(Locale.US);
                for (String m : markers) {
                    if (lower.contains(m)) return true;
                }
            }
            int count = node.getChildCount();
            for (int i = 0; i < count; i++) {
                AccessibilityNodeInfo child = node.getChild(i);
                if (child != null) queue.add(child);
            }
        }
        return false;
    }

    private void block(String pkg, boolean exhausted) {
        long now = SystemClock.elapsedRealtime();
        if (now - lastBlock < 900L) return;
        lastBlock = now;
        blockStreak++;

        // TikTok, or a screen that refuses to close with Back: go to the home screen.
        if (TIKTOK.contains(pkg) || blockStreak >= 3) {
            performGlobalAction(GLOBAL_ACTION_HOME);
            blockStreak = 0;
        } else {
            performGlobalAction(GLOBAL_ACTION_BACK);
        }

        if (now - lastToast > 4000L) {
            lastToast = now;
            Toast.makeText(this,
                    exhausted ? R.string.toast_exhausted : R.string.toast_locked,
                    Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onInterrupt() {
        // Nothing to interrupt.
    }

    @Override
    public void onDestroy() {
        running = false;
        handler.removeCallbacks(tick);
        super.onDestroy();
    }
}
