# Save your time

تطبيق أندرويد يقفل الريلز في إنستغرام وتيك توك وX، ويسمح بساعة واحدة يومياً كحد أقصى عبر زر واحد.

## بناء التطبيق ونشر الموقع مجاناً عبر GitHub (من الجوال)

1. أنشئ حساباً في github.com إن لم يكن لديك.
2. أنشئ مستودعاً جديداً **عاماً (Public)** باسم `save-your-time`، وفعّل خيار **Add a README file**.
3. داخل المستودع: **Add file ← Upload files** وارفع الملف `project.zip` كما هو، ثم **Commit changes**.
4. **Settings ← Pages ← Source** واختر **GitHub Actions**.
5. **Actions ← New workflow ← set up a workflow yourself**، امسح المحتوى والصق محتوى الملف `build.yml`، ثم **Commit changes**.
6. انتظر حوالي 5 دقائق حتى تظهر علامة ✅ في تبويب Actions.
7. موقعك جاهز على:
   `https://اسم-المستخدم.github.io/save-your-time/`
   ومنه تحمّل `SaveYourTime.apk`.

> من الكمبيوتر يمكنك بدلاً من ذلك رفع محتويات المجلد مباشرة (بما فيها `.github/workflows/build.yml`) وتخطي الخطوة 5.

## بنية المشروع

| المسار | الوظيفة |
|---|---|
| `app/src/main/java/.../ReelsBlockerService.java` | خدمة إمكانية الوصول: تكتشف شاشة الريلز وتغلقها أو تحتسب وقتها |
| `app/src/main/java/.../UsageStore.java` | رصيد اليوم (60 دقيقة) والتجديد عند منتصف الليل |
| `app/src/main/java/.../MainActivity.java` | الشاشة الرئيسية والزر |
| `app/src/main/java/.../TimeRingView.java` | الدائرة التي تمتلئ مع استهلاك الوقت |
| `website/index.html` | صفحة التحميل |
| `.github/workflows/build.yml` | يبني الـAPK وينشر الموقع على GitHub Pages |

## طريقة التعرف على الريلز

- **TikTok**: التطبيق كاملاً.
- **Instagram**: أي عنصر ظاهر يحتوي معرّفه على `clips_viewer` (عارض الريلز).
- **X**: نافذة أو عنصر يحتوي على `immersive` (عارض الفيديو العمودي).

إن غيّرت ميتا أو X تركيب تطبيقاتهما، عدّل `IG_MARKERS` أو `X_MARKERS` في `ReelsBlockerService.java` ثم ارفع التعديل، وسيُعاد البناء تلقائياً.
